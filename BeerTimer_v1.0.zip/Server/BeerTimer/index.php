<html>
<head>
    <title>BeerTimer</title>
    <link rel="stylesheet" type="text/css" href="style.css"/>


</head>
<body>
<div id="container">
    <?php
        include 'db.php';


        $result = mysqli_query($db, "SELECT Name, Time FROM scores ORDER BY Time");
        while($row = mysqli_fetch_assoc($result))
            echo '<div class="entry">' . $row['Name'] . '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' . $row['Time'] . '</div>';
    ?>
</div>

</body>
</html>