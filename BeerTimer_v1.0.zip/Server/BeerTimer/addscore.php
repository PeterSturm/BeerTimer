<?php
/**
 * Created by PhpStorm.
 * User: anthor
 * Date: 2015.05.13.
 * Time: 18:45
 */

    include 'db.php';

    $name = $_GET['name'];
    $time = $_GET['time'];


    $query = "INSERT INTO scores (Name, Time) VALUES ('$name', '$time')";

    if (!mysqli_query($db, $query)) {
        die('Error: ' . mysqli_error($db));
    }

?>